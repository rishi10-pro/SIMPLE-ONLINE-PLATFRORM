# MyPlatform - Simple Online Platform

A clean, responsive, and user-friendly web platform built with HTML and CSS. This platform features a modern design with sections for features showcase and user contact.

## Features

- 🎨 Modern and clean design
- 📱 Fully responsive layout
- ⚡ Fast and lightweight
- 📝 Contact form with thank you page
- 🎯 Easy navigation

## Getting Started

### Prerequisites

- Node.js (Latest LTS version recommended)
- npm (Comes with Node.js)

### Installation

1. Clone the repository or download the files
2. Install dependencies:
```bash
npm install
```

### Development

To start the development server:
```bash
npm run dev
```

The site will be available at `http://localhost:5173`

### Building for Production

To create a production build:
```bash
npm run build
```

The built files will be in the `dist` directory.

## Project Structure

```
/
├── index.html          # Main landing page
├── thank-you.html      # Contact form confirmation page
├── style.css          # Global styles
├── main.js            # JavaScript file (currently empty)
├── package.json       # Project configuration
└── README.md          # Project documentation
```

## Sections

1. **Header**
   - Navigation menu
   - Responsive logo

2. **Hero Section**
   - Welcome message
   - Main call-to-action

3. **Features**
   - Easy to Use
   - Fast Loading
   - Responsive Design

4. **Contact Form**
   - Name input
   - Email input
   - Message textarea
   - Submit button with confirmation page

## Customization

You can customize the platform by modifying the CSS variables in `style.css`:

```css
:root {
  --primary-color: #646cff;
  --secondary-color: #535bf2;
  --background-color: #ffffff;
  --text-color: #213547;
  --card-background: #f9f9f9;
}
```

## License

© 2024 MyPlatform. All rights reserved.